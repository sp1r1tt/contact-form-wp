<?php get_header(); ?>
<h1>Використовуйте шаблон Test Contact для головної сторінки</h1>
<?php get_footer(); ?>